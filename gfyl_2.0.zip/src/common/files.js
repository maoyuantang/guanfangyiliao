// export default {
//     aaa:function(data){alert(data)}
// }
function aaa(data){
    // alert(data)
}
var o=1
export default { aaa }