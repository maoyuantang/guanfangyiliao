<template>
    <div style="text-align:center">
        <img src="../../../static/assets/img/nohave.png" />
        <!-- <div>
            暂无数据
        </div> -->
    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>
