<template>
    <div class="steps">
        <div class="stept-item">
            
        </div>
    </div>
</template>

<script>
	export default {
        name : 'steps',
        props:[
            "inData"
        ],
		computed:{
		},
		data(){
            return { }
		},
		methods:{
		},
		async created(){
		}
	}
</script>

<style scoped>
    .steps{}
</style>