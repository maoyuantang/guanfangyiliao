<template>
	<div class="follow-up-table">
		followUpTable
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.follow-up-table{

    }
</style>