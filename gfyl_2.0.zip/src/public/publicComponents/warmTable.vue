<template>
	<div class="warm-table">
		warmTable
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){
		}
	}
</script>

<style scoped>
	.warm-table{

    }
</style>