<template>
	<div class="plant-table">
		plantTable
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.plant-table{

    }
</style>