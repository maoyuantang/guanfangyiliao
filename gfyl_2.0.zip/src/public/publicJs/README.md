作用：放置公共方法

具体说明：
	sensitiveWordCheck.js   =>   检查字符串中是否有敏感字，详情该文件内有说明
	carryNum.js             =>   将数字最高位加1，其余位置0