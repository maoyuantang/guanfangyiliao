import echarts from 'echarts'

export default echarts
