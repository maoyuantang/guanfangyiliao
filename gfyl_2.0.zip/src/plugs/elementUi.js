import elementUi from 'element-ui'

export default elementUi