import iview from 'iview'

export default iview