export default {
	baseApiURL:"http://localhost:3000/users",
	baseImgURL:""
}
