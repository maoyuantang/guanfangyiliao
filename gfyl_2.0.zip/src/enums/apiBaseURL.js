module.exports =  {
    developmentEnvironment:"https://demo.chuntaoyisheng.com:10002",//开发环境
    testEnvironment:"https://demo.chuntaoyisheng.com:10001",//测试环境
    onlineEnvironment:"https://api.chuntaoyisheng.com"//线上环境
}