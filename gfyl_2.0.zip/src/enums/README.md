enums => enums.js
	返回通用常量
	包括：
		baseApiURL ：api接口基础路径
		baseImgURL ：图片基础路径 