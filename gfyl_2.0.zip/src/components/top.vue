<template>
<div class="top">
	<div class="top-left">
		<marquee class="title-marquee">{{marquee}}</marquee>
		<div class="msg"><i class="iconfont msg-icon">&#xe8c0;</i></div>
	</div>
	<div class="top-right">
		<div class="top-right-posi">
			<img src="../assets/logo.png" alt="" class="user-head">
			<span class="user-name">kisu</span>
			<!-- <Dropdown>
				<i class="iconfont user-select" :class="isClick?'user-select-true':''" @click="switchStatus">&#xe65a;</i>
				<DropdownMenu slot="list">
					<DropdownItem @click="switchStatus">驴打滚</DropdownItem>
					<DropdownItem>炸酱面</DropdownItem>
					<DropdownItem disabled>豆汁儿</DropdownItem>
					<DropdownItem>冰糖葫芦</DropdownItem>
					<DropdownItem divided>北京烤鸭</DropdownItem>
				</DropdownMenu>
			</Dropdown> -->
			<i class="iconfont user-select" :class="isClick?'user-select-true':''" @click="switchStatus">&#xe65a;</i>
			<div class="detailed-info" v-show="isClick"></div>
		</div>
	</div>
</div>
</template>

<script>
	export default {
		name : 'top',
		data(){
			return {
				isClick:false,
				marquee:'i is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fishi is fish'
			}
		},
		methods:{
			switchStatus(){
				console.log('444')
				this.isClick = !this.isClick;
			}
		}
	}
</script>

<style scoped>
	.top{
		background-color: var(--whiteColor);
		box-shadow: 0 0.06rem 0.36rem 0 rgba(0,62,100,0.04);
		height: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.top-left{
		flex: 1;
		width: 0;
		height: 100%;
		display: flex;
		align-items: center;
	}
	.top-right{
		width: 1.8rem;
		height: 100%;
		display: flex;
		align-items: center
	}
	.top-right-posi{
		position: relative;
		display: flex;
		align-items: center;
		
	}
	.user-head{
		width: 0.3rem;
		height: 0.3rem;
		border-radius: 50%;
		margin-left: 0.16rem;
	}
	.user-name{
		font-family: Helvetica;
		font-size: var(--fontSize3);
		color: var(--color1);
		margin-left: 0.16rem;
		
	}
	.user-select{
		font-size: 0.12rem;
		margin-left: 0.16rem;
		transition: 0.5s;
		transform:rotate(0deg);
		cursor: pointer;
		color: var(--color1);
		-webkit-touch-callout: none; /* iOS Safari */
		-webkit-user-select: none; /* Chrome/Safari/Opera */
		-khtml-user-select: none; /* Konqueror */
		-moz-user-select: none; /* Firefox */
		-ms-user-select: none; /* Internet Explorer/Edge */
		user-select: none; /* Non-prefixed version, currently*/
	}
	.user-select-true{
		transform:rotate(180deg);
	}
	.detailed-info{
		width: 300px;
		height: 200px;
		background-color: yellow;
		position: absolute;
		top: 0.3rem;
	}
	.title-marquee{
		color: var(--color2);
		font-family: PingFangSC-Regular;
		letter-spacing: 0.005rem;
		line-height: 0.3rem;
	}
	.msg{
		width: 0.73rem;
		display: flex;
		justify-content: center;
		color: var(--color2);
	}
	.msg-icon{
		position: relative;
	}
	.msg-icon::after{
		content: '';
		display: block;
		width: 0.08rem;
		height: 0.08rem;
		border-radius: 50%;
		background: var(--bgColor2);
		position:absolute;
		top: 0;
		right: -0.08rem;
	}
</style>