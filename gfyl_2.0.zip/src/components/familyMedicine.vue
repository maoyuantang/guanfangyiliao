<template>
	<div class="family-medicine">
		家医系统
	</div>
</template>

<script>
	export default {
		data () {
			return {
				mag:'familyMedicine'
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.family-medicine{

    }
</style>