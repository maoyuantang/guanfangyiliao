<template>
  <div class="statistics">statistics</div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {},
  async created() {}
};
</script>

<style scoped>
.statistics {
}
</style>