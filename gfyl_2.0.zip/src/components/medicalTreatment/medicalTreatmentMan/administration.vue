<template>
  <div class="administration">administration</div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {},
  async created() {}
};
</script>

<style scoped>
.administration {
}
</style>