<template>
  <div class="control">control</div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {},
  async created() {}
};
</script>

<style scoped>
.control {
}
</style>