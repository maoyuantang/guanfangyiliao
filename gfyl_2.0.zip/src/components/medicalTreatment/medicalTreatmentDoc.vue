<template>
	<div class="medical-treatment-doc">
		<noData></noData>
	</div>
</template>

<script>
	import normalTab from './../../public/publicComponents/normalTab.vue'
	import noData from './../../public/publicComponents/noData.vue'

	export default {
		components: {
			normalTab,
			noData
		},
		data() {
			return {

			}
		},
		methods: {

		},
		async created() {

		}
	}
</script>

<style scoped>
</style>