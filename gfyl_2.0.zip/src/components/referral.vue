<template>
  <div>
    <div>
      <normalTab v-model="navInfo" @reBack="getNav"></normalTab>
    </div>
  </div>
</template>

<script>
  //引入组件
	import normalTab from '../public/publicComponents/normalTab.vue'
  export default {
    components: {
			normalTab,
		},
    data() {
      return {
        msg: 123,
        navInfo: {
          i: 0,
          list: [
            {
              en: 'online clinic',//选项英文，类型 string
              zh: '在线诊室管理'//选项中文，类型string
            },
            {
              en: 'Prescription Audit & Distribution',
              zh: '处方审核和配送'
            },
            {
              en: 'statistics',
              zh: '统计'
            },
          ]
        },
      }
    },
    computed: {

    },
    mounted() {

    },
    methods: {
      //转诊管理、统计、切换插件返回值
			getNav(data) {
				console.log(data)
			},
    },
    components: {

    }
  }
</script>

<style lang="scss" scoped>

</style>