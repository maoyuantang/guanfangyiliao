<template>
	<div class="referral">
		双向转诊系统
		//家医服务
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.referral{

    }
</style>