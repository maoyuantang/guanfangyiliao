<!-- 告警 -->
<template>
	<div>
		告警
	</div>
</template>

<script>
	export default {
		components:{
			
		},
		watch:{
			
		},
		computed:{
			
		},
		
		data () {
			return {	
			}
		},
		
		methods:{
			
			
		},
		async created(){
			
		}
	}
</script>

<style >
	
</style>