<!-- 远程会诊 -->
<template>
	<div>
		远程会诊
	</div>
</template>

<script>
	export default {
		components:{
			
		},
		watch:{
			
		},
		computed:{
			
		},
		
		data () {
			return {	
			}
		},
		
		methods:{
			
			
		},
		async created(){
			
		}
	}
</script>

<style >
	
</style>