<!-- 远程协作 -->
<template>
	<div>
		远程协作
	</div>
</template>

<script>
	export default {
		components:{
			
		},
		watch:{
			
		},
		computed:{
			
		},
		
		data () {
			return {	
			}
		},
		
		methods:{
			
			
		},
		async created(){
			
		}
	}
</script>

<style >
	
</style>