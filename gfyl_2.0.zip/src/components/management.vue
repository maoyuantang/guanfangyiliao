<template>
	<div class="management">
		终端管理系统
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.management{

    }
</style>