<!-- 所有项目 -->
<template>
	<div>
		所有项目
        <p>{{inData}}</p>
	</div>
</template>

<script>
	export default {
        props:[
            "inData"
        ],
		components:{
			
		},
		watch:{
			
		},
		computed:{
			
		},
		
		data () {
			return {	
			}
		},
		
		methods:{
			
			
		},
		async created(){
			
		}
	}
</script>

<style >
	
</style>