<template>
	<div class="rounds">
		移动查房系统
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.rounds{

    }
</style>