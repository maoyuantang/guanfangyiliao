<template>
	<div class="medicalTreatment">
		分级诊疗系统
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.medicalTreatment{

    }
</style>