<template>
	<div class="cloud-management">
		云存储管理
	</div>
</template>

<script>
	export default {
		data () {
			return {
				
			}
		},
		methods:{
			
		},
		async created(){

		}
	}
</script>

<style scoped>
	.cloud-management{

    }
</style>