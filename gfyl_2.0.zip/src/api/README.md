改文件夹放置api接口文件
	test.js : 测试接口文件